function doClick(o){
     o.className="task-tabHead_selected";
     var j;
     var id;
     var e;
     for(var i=1;i<=2;i++){
       id ="nav"+i;
       j = document.getElementById(id);
       e = document.getElementById("sub"+i);
       if(id != o.id){
         j.className="task-tabHead_Noselected";
         e.style.display = "none";
       }else{
            e.style.display = "block";
       }
     }
   }